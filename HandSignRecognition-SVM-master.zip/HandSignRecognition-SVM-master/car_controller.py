def performOperation(operationName):
    print "operationName ", operationName