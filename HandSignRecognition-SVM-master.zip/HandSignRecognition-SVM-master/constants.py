# Top left corner of ROI.
(x_roi, y_roi) = (400, 100)
# Actual Width of ROI.
(widthRoi, heightRoi) = (200, 200)
# Width after resize of ROI.
(sample_width, sample_height) = (100, 100)


# Binary mask constants
binaryMask_minThreshold = 70

# Dataset constants
path_data_storage = "datasets/"
dataset_folder_name = "dataset100/"
test_folder_name = "testPortion/"