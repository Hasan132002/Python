# Hand-sign Recognition
#### (Using SVM and Computer Vision)